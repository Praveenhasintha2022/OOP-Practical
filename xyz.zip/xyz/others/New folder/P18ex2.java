// Publication.java
class Publication {
    protected String title;
    protected double price;

    public Publication(String title, double price) {
        this.title = title;
        this.price = price;
    }

    public void getData() {
        System.out.println("Title: " + title);
        System.out.println("Price: " + price);
    }

    public void print() {
        System.out.println("Printing Publication...");
    }
}

// Interface Book
interface Book {
    void getData();
    void print();
}

// Interface Magazine
interface Magazine {
    void getData();
    void print();
}

// Journal.java
class Journal extends Publication implements Book, Magazine {
    private String journalName;

    public Journal(String title, double price, String journalName) {
        super(title, price);
        this.journalName = journalName;
    }

    @Override
    public void getData() {
        super.getData();
        System.out.println("Journal Name: " + journalName);
    }

    @Override
    public void print() {
        System.out.println("Printing Journal...");
    }
}

// Main.java
public class P18ex2 {
    public static void main(String[] args) {
        Journal journal1 = new Journal("Journal 1", 10.99, "Journal Name 1");
        Journal journal2 = new Journal("Journal 2", 15.99, "Journal Name 2");
        Journal journal3 = new Journal("Journal 3", 20.99, "Journal Name 3");
        Journal journal4 = new Journal("Journal 4", 25.99, "Journal Name 4");
        Journal journal5 = new Journal("Journal 5", 30.99, "Journal Name 5");

        journal1.getData();
        journal1.print();
        System.out.println();

        journal2.getData();
        journal2.print();
        System.out.println();

        journal3.getData();
        journal3.print();
        System.out.println();

        journal4.getData();
        journal4.print();
        System.out.println();

        journal5.getData();
        journal5.print();
    }
}
