// CarExhibition class
public class CarExhibition {
    private Car[] cars;
    private int size;
    private static final int MAX_CARS = 100;

    public CarExhibition() {
        cars = new Car[MAX_CARS];
        size = 0;
    }

    // Add a generic car to the exhibition
    public void addCar(double price, int year) {
        if (size < MAX_CARS) {
            cars[size++] = new SportCar(price, year); // Change here
        } else {
            System.out.println("Exhibition is full. Cannot add more cars.");
        }
    }

    // Add a sports car to the exhibition
    public void addSportCar(double price, int year) {
        if (size < MAX_CARS) {
            cars[size++] = new SportCar(price, year);
        } else {
            System.out.println("Exhibition is full. Cannot add more cars.");
        }
    }

    // Calculate the total price of all cars in the exhibition
    public double getTotalPrice() {
        double totalPrice = 0.0;
        for (int i = 0; i < size; i++) {
            totalPrice += cars[i].calculateSalePrice();
        }
        return totalPrice;
    }

    public static void main(String[] args) {
        CarExhibition exhibition = new CarExhibition();

        exhibition.addCar(20000, 2010);
        exhibition.addSportCar(30000, 2018);
        exhibition.addCar(15000, 2005);

        System.out.println("Total Price of all cars: $" + exhibition.getTotalPrice());
    }
}

// Abstract Car class
abstract class Car {
    protected double price;
    protected int year;

    // Constructor
    public Car(double price, int year) {
        this.price = price;
        this.year = year;
    }

    // Abstract method to calculate sale price
    public abstract double calculateSalePrice();
}

// SportCar class
class SportCar extends Car {
    public SportCar(double price, int year) {
        super(price, year);
    }

    @Override
    public double calculateSalePrice() {
        if (year > 2015) {
            return price * 1.75; // 75% higher
        } else if (year > 2005) {
            return price * 1.5; // 50% higher
        } else {
            return price * 1.25; // 25% higher
        }
    }
}

// ClassicCar class
class ClassicCar extends Car {
    public ClassicCar(double price, int year) {
        super(price, year);
    }

    @Override
    public double calculateSalePrice() {
        return 10000; // Sale price is always $10,000
    }
}
