import java.util.Scanner;

class Hospital {
    private String name;
    private String address;
    private Patient[] patients;
    private Department[] departments;
    private int patientCount;
    private int departmentCount;

    public Hospital(String name, String address) {
        this.name = name;
        this.address = address;
        this.patients = new Patient[100];
        this.departments = new Department[10];
        this.patientCount = 0;
        this.departmentCount = 0;
    }

    public void addPatient(Patient patient) {
        patients[patientCount++] = patient;
    }

    public void removePatient(Patient patient) {
        for (int i = 0; i < patientCount; i++) {
            if (patients[i] == patient) {
                patients[i] = null;
                break;
            }
        }
    }

    public Patient[] getPatients() {
        return patients;
    }

    public void addDepartment(Department department) {
        departments[departmentCount++] = department;
    }

    public void removeDepartment(Department department) {
        for (int i = 0; i < departmentCount; i++) {
            if (departments[i] == department) {
                departments[i] = null;
                break;
            }
        }
    }

    public Department[] getDepartments() {
        return departments;
    }

    public void printDepartments() {
        System.out.println("Available Departments:");
        for (Department department : departments) {
            if (department != null) {
                System.out.println("- " + department.getName());
            }
        }
    }
}

class Department {
    private String name;
    private TeamMember[] staff;
    private int teamMemberCount;

    public Department(String name) {
        this.name = name;
        this.staff = new TeamMember[20];
        this.teamMemberCount = 0;
    }

    public void addTeamMember(TeamMember teamMember) {
        staff[teamMemberCount++] = teamMember;
    }

    public void removeTeamMember(TeamMember teamMember) {
        for (int i = 0; i < teamMemberCount; i++) {
            if (staff[i] == teamMember) {
                staff[i] = null;
                break;
            }
        }
    }

    public TeamMember[] getStaff() {
        return staff;
    }

    public String getName() {
        return name;
    }
}

class TeamMember {
    protected String name;
    protected String id;
    private String gender;
    private String joinDate;
    private int maxWorkingHours = 12;

    public TeamMember(String name, String id, String gender, String joinDate) {
        this.name = name;
        this.id = id;
        this.gender = gender;
        this.joinDate = joinDate;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public void treatPatient(Patient patient) {
        // Abstract method to be implemented by subclasses
    }
}

class Doctor extends TeamMember {
    private String specialty;
    private Patient[] patients;
    private int patientCount;

    public Doctor(String name, String id, String gender, String joinDate, String specialty) {
        super(name, id, gender, joinDate);
        this.specialty = specialty;
        this.patients = new Patient[20];
        this.patientCount = 0;
    }

    public String getSpecialty() {
        return specialty;
    }

    public String getId() {
        return id;
    }

    public void treatPatient(Patient patient) {
        // Common treatment logic for all doctors
        patient.setDiagnosis("Treatment in progress");
        patient.setDoctor(this);
        patient.setDaysToStay(7);
    }
}

class Intern extends Doctor {
    private SeniorDoctor supervisor;

    public Intern(String name, String id, String gender, String joinDate, String specialty, SeniorDoctor supervisor) {
        super(name, id, gender, joinDate, specialty);
        this.supervisor = supervisor;
    }
}

class SeniorDoctor extends Doctor {
    public SeniorDoctor(String name, String id, String gender, String joinDate, String specialty) {
        super(name, id, gender, joinDate, specialty);
    }
}

class Surgeon extends Doctor {
    public Surgeon(String name, String id, String gender, String joinDate, String specialty) {
        super(name, id, gender, joinDate, specialty);
    }
}

class Patient {
    private String name;
    private String birthDate;
    private String gender;
    private String admissionDate;
    private String diagnosis;
    private TeamMember doctor;
    private int daysToStay;

    public Patient(String name, String birthDate, String gender, String admissionDate) {
        this.name = name;
        this.birthDate = birthDate;
        this.gender = gender;
        this.admissionDate = admissionDate;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    public void setDoctor(TeamMember doctor) {
        this.doctor = doctor;
    }

    public void setDaysToStay(int days) {
        this.daysToStay = days;
    }

    public String getName() {
        return name;
    }

    public TeamMember getDoctor() {
        return doctor;
    }

    public int getDaysToStay() {
        return daysToStay;
    }

    @Override
    public String toString() {
        return "Patient: " + name + " (Admission Date: " + admissionDate + ")";
    }
}

class Nurse extends TeamMember {
    public Nurse(String name, String id, String gender, String joinDate) {
        super(name, id, gender, joinDate);
    }

    @Override
    public String toString() {
        return "Nurse: " + getName() + " (ID: " + getId() + ")";
    }
}


public class HospitalApplication {
    public static void main(String[] args) {
        System.out.println("Hospital Name: Nawaloka");
        System.out.println("Address: Colombo");

        Hospital myHospital = new Hospital("Nawaloka", "Colombo");

        Department emergencyDepartment = new Department("Emergency Department");
        emergencyDepartment.addTeamMember(new Doctor("Dr. John", "D001", "Male", "01-01-2023", "Emergency Medicine"));
        emergencyDepartment.addTeamMember(new Nurse("Nurse Jane", "N001", "Female", "01-01-2023"));

        Department burnUnitDepartment = new Department("Burn Unit Department");
        burnUnitDepartment.addTeamMember(new Doctor("Dr. Smith", "D002", "Male", "01-01-2023", "Burn Medicine"));
        burnUnitDepartment.addTeamMember(new Nurse("Nurse Kate", "N002", "Female", "01-01-2023"));

        Department surgeryDepartment = new Department("Surgery Department");
        surgeryDepartment.addTeamMember(new Surgeon("Dr. Anderson", "D003", "Male", "01-01-2023", "General Surgery"));
        surgeryDepartment.addTeamMember(new Nurse("Nurse Mike", "N003", "Male", "01-01-2023"));

        Department cardiologyDepartment = new Department("Cardiology Department");
        cardiologyDepartment.addTeamMember(new SeniorDoctor("Dr. Wilson", "D004", "Male", "01-01-2023", "Cardiology"));
        cardiologyDepartment.addTeamMember(new Nurse("Nurse Emily", "N004", "Female", "01-01-2023"));

        Department cancerDepartment = new Department("Cancer Department");
        cancerDepartment.addTeamMember(new SeniorDoctor("Dr. Brown", "D005", "Male", "01-01-2023", "Oncology"));
        cancerDepartment.addTeamMember(new Nurse("Nurse Sarah", "N005", "Female", "01-01-2023"));

        myHospital.addDepartment(emergencyDepartment);
        myHospital.addDepartment(burnUnitDepartment);
        myHospital.addDepartment(surgeryDepartment);
        myHospital.addDepartment(cardiologyDepartment);
        myHospital.addDepartment(cancerDepartment);

        System.out.println("\n--- Department Section ---");
        myHospital.printDepartments();

        Scanner scanner = new Scanner(System.in);

        System.out.println("\n--- Add/Remove Team Members ---");
        System.out.print("Enter department name to manage team members: ");
        String departmentName = scanner.nextLine();
        Department selectedDepartment = findDepartmentByName(myHospital, departmentName);

        if (selectedDepartment != null) {
            System.out.println("\nTeam Members in " + departmentName + ":");
            printTeamMembers(selectedDepartment);

            System.out.print("\nEnter team member name to remove: ");
            String teamMemberToRemove = scanner.nextLine();
            removeTeamMemberByName(selectedDepartment, teamMemberToRemove);
            System.out.println("Team member removed successfully!");

            System.out.println("\nTeam Members in " + departmentName + " after removing team member:");
            printTeamMembers(selectedDepartment);

            System.out.print("\nEnter team member name to add: ");
            String teamMemberToAdd = scanner.nextLine();
            addTeamMemberByName(selectedDepartment, teamMemberToAdd);
            System.out.println("Team member added successfully!");

            System.out.println("\nTeam Members in " + departmentName + " after adding team member:");
            printTeamMembers(selectedDepartment);
        } else {
            System.out.println("Department not found!");
        }

        // Patient Section
        System.out.println("\n--- Patient Section ---");
        System.out.println("1. Add Patient");
        System.out.println("2. Remove Patient");
        System.out.println("3. View Patients");

        System.out.print("Enter choice (1-3): ");
        int patientChoice = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character

        switch (patientChoice) {
            case 1:
                // Add Patient
                System.out.print("Enter patient name: ");
                String patientName = scanner.nextLine();
                System.out.print("Enter patient birth date: ");
                String patientBirthDate = scanner.nextLine();
                System.out.print("Enter patient gender: ");
                String patientGender = scanner.nextLine();
                System.out.print("Enter admission date: ");
                String admissionDate = scanner.nextLine();

                Patient newPatient = new Patient(patientName, patientBirthDate, patientGender, admissionDate);
                myHospital.addPatient(newPatient);
                System.out.println("Patient added successfully!");
                break;

            case 2:
                // Remove Patient
                System.out.print("Enter patient name to remove: ");
                String patientToRemove = scanner.nextLine();
                removePatientByName(myHospital, patientToRemove);
                System.out.println("Patient removed successfully!");
                break;

            case 3:
                // View Patients
                System.out.println("\n--- Patients ---");
                for (Patient patient : myHospital.getPatients()) {
                    if (patient != null) {
                        System.out.println("- " + patient);
                    }
                }
                break;

            default:
                System.out.println("Invalid choice!");
        }
    }

    private static void printTeamMembers(Department department) {
        for (TeamMember teamMember : department.getStaff()) {
            if (teamMember != null) {
                System.out.println("- " + teamMember);
            }
        }
    }

    private static void removeTeamMemberByName(Department department, String name) {
        for (int i = 0; i < department.getStaff().length; i++) {
            if (department.getStaff()[i] != null && department.getStaff()[i].getName().equalsIgnoreCase(name)) {
                department.getStaff()[i] = null;
                break;
            }
        }
    }

    private static void addTeamMemberByName(Department department, String name) {
        for (int i = 0; i < department.getStaff().length; i++) {
            if (department.getStaff()[i] == null) {
                department.getStaff()[i] = new Nurse(name, "N00" + i, "Female", "01-01-2023");
                break;
            }
        }
    }

    private static void removePatientByName(Hospital hospital, String name) {
        for (int i = 0; i < hospital.getPatients().length; i++) {
            if (hospital.getPatients()[i] != null && hospital.getPatients()[i].getName().equalsIgnoreCase(name)) {
                hospital.getPatients()[i] = null;
                break;
            }
        }
    }

    private static Department findDepartmentByName(Hospital hospital, String name) {
        for (Department department : hospital.getDepartments()) {
            if (department != null && department.getName().equalsIgnoreCase(name)) {
                return department;
            }
        }
        return null;
    }
}
