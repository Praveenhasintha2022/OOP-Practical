import java.util.Scanner;
//StudentGradeCalculator
public class StudentGradeCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.print("Step 1: Input Student registration number: ");
            String registrationNumber = scanner.nextLine();
            
            System.out.print("Step 2: Input quiz score: ");
            int quizScore = scanner.nextInt();
            if (quizScore > 10) {
                System.out.println("Invalid Input!");
                continue;
            }
            
            System.out.print("Step 4: Input assignment score: ");
            int assignmentScore = scanner.nextInt();
            if (assignmentScore > 10) {
                System.out.println("Invalid Input!");
                continue;
            }
            
            System.out.print("Step 6: Input mid-term exam score: ");
            int midtermScore = scanner.nextInt();
            if (midtermScore > 20) {
                System.out.println("Invalid Input!");
                continue;
            }
            
            System.out.print("Step 8: Input final exam score: ");
            int finalExamScore = scanner.nextInt();
            if (finalExamScore > 60) {
                System.out.println("Invalid Input!");
                continue;
            }
            
            int totalScore = quizScore + assignmentScore + midtermScore + finalExamScore;
            if (totalScore > 55) {
                System.out.println("Grade: Pass");
            } else {
                System.out.println("Grade: Fail");
            }
            
            System.out.println("Step 11: Process next student grade.");
            scanner.nextLine(); // Consume newline
        }
    }
}