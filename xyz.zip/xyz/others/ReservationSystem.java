import java.util.Scanner;

 public class ReservationSystem {
			 
			 
        private static int[] ticket = new int[13];

        public static void main(String[] args) {
			System.out.println(" ############################################################################################   ");	
			System.out.println("           COLOMBO-TRINCOMALLEE RAILWAY RESERVATION SYSTEM   \n");
			System.out.println(" ############################################################################################   ");	

			System.out.print("You can book a ticket by selecting the type of ticket you want.");
			System.out.println("\nThe tickets are non-refundable and once you book you cannot refund");

         for (int i = 0; i < 12; i++) {
             ticket[i] = 0;
             }


         Scanner s = new Scanner(System.in);
         int choice = 1;


         System.out.println("\nSelect the type of ticket you want\n");
		 System.out.println("1. Second Class");
		 System.out.println("2. Third Class");
		 System.out.println("0. Exit");
         choice = s.nextInt();

        while (choice != 0) {
            int seatnumber = 0;


            if (choice == 1) {
                 seatnumber = secondClass();

                 if (seatnumber == -1) {
                      seatnumber = thirdClass();

                     if (seatnumber != -1) {
                         System.out.println("Sorry, there are no Second Class Tickets available. But we  have Third class tickets.");
                         ticketBooking(seatnumber);
                         }
                    }
					
                 else {
                     System.out.println("Second Class Tickets available");
                     ticketBooking(seatnumber);
                     }
                 }
				 
             else if (choice == 2) {
                 seatnumber = thirdClass();

                 if (seatnumber == -1) {
                     seatnumber = secondClass();

                     if (seatnumber != -1) {
                         System.out.println("Sorry, there are no Third Class ticket available. But we  have Seond Class Ticket Available.");
                         ticketBooking(seatnumber);
                         }
                     }
					 
                 else {
                     System.out.println("Third Class Tickets available");
                     ticketBooking(seatnumber);
                     }
                 }
				 
             else {
                 System.out.println("Invalid choice");
                 choice = 0;
                 }

             if (seatnumber == -1) {
                 System.out.println("Sorry, We have got no tickets available");
                         System.out.println();
                 }


				System.out.print("Please select your type of Ticket:\n");
				System.out.println("1. Second Class");
				System.out.println("2. Third Class");
				System.out.println("0. Exit");
				choice = s.nextInt();
             }


         }

         private static int secondClass() {
         for (int i = 0; i < 6; i++) {
            if (ticket[i] == 0) {
                 ticket[i] = 1;
                 return i + 1;
                 }
             }
         return -1;
         }

         private static int thirdClass() {
         for (int i = 6; i < 12; i++) {
            if (ticket[i] == 0) {
                 ticket[i] = 1;
                 return i + 1;
                 }
             }
         return -1;

         }


private static void ticketBooking(int ticketNumber) {
         
         System.out.println();
         System.out.println("Your Ticket number: " + ticketNumber);
         System.out.println("\nBooking Successful!!!");
         System.out.println("This ticket is non-refundable.");
		 System.out.println("\n----------------------------------------------------------------------------");
         System.out.println();
        }
 }