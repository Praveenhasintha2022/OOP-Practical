public class RomanConverter {
    private static int[] integerValues = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
    private static String[] romanNumerals = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};

    public static int romanToInt(String s) {
        int result = 0;
        int index = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            int value = getValue(c);
            if (i + 1 < s.length()) {
                int nextValue = getValue(s.charAt(i + 1));
                if (nextValue > value) {
                    result += (nextValue - value);
                    i++; // Skip the next character
                    continue;
                }
            }
            result += value;
        }
        return result;
    }

    public static String intToRoman(int num) {
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (num > 0) {
            if (num >= integerValues[i]) {
                sb.append(romanNumerals[i]);
                num -= integerValues[i];
            } else {
                i++;
            }
        }
        return sb.toString();
    }

    private static int getValue(char c) {
        switch (c) {
            case 'M':
                return 1000;
            case 'D':
                return 500;
            case 'C':
                return 100;
            case 'L':
                return 50;
            case 'X':
                return 10;
            case 'V':
                return 5;
            case 'I':
                return 1;
            default:
                return 0;
        }
    }

    public static void main(String[] args) {
        String romanNumber = "MCMLXXVI"; // Example Roman number
        int integerNumber = 1976; // Example integer number

        System.out.println("Roman to Integer: " + romanToInt(romanNumber));
        System.out.println("Integer to Roman: " + intToRoman(integerNumber));
    }
}
