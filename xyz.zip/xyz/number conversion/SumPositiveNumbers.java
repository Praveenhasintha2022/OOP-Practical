import java.util.Scanner;

public class SumPositiveNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int sum = 0;
        int count = 0;
        
        while (count < 10) {
            System.out.print("Enter an integer: ");
            int number = scanner.nextInt();
            
            if (number < 0) {
                break; // Terminate the loop if a negative number is entered
            }
            
            if (number > 0) {
                sum += number;
            }
            
            count++;
        }
        
        System.out.println("Sum of positive numbers: " + sum);
        
        scanner.close();
    }
}

