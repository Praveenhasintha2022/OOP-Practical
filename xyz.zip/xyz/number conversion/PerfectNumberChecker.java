import java.util.Scanner;

public class PerfectNumberChecker {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a positive integer: ");
        int number = scanner.nextInt();
        
        if (isPerfectNumber(number)) {
            System.out.println(number + " is a perfect number.");
        } else {
            System.out.println(number + " is not a perfect number.");
        }
        
        scanner.close();
    }
    
    // Function to check if a number is perfect
    public static boolean isPerfectNumber(int num) {
        if (num <= 0) {
            return false; // Negative numbers and zero cannot be perfect numbers.
        }
        
        int sumOfDivisors = 0;
        
        // Find proper divisors and calculate their sum
        for (int i = 1; i < num; i++) {
            if (num % i == 0) {
                sumOfDivisors += i;
            }
        }
        
        // Check if the sum of divisors equals the original number
        return sumOfDivisors == num;
    }
}