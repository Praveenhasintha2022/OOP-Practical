import java.util.Scanner;

public class SwapIntegers {

    // Function to swap two integer values
    public static void swap(int a, int b) {
        System.out.println("Before swapping: a = " + a + ", b = " + b);

        // Swap values
        int temp = a;
        a = b;
        b = temp;

        System.out.println("After swapping: a = " + a + ", b = " + b);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input two integers from the user
        System.out.print("Enter the first integer (a): ");
        int num1 = scanner.nextInt();

        System.out.print("Enter the second integer (b): ");
        int num2 = scanner.nextInt();

       
        swap(num1, num2);

        // Close the scanner
        scanner.close();
    }
}