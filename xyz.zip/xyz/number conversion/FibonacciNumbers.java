public class FibonacciNumbers {
    public static void main(String[] args) {
        int maxNumber = 100;
        int prev = 0;
        int current = 1;
        
        System.out.println("Fibonacci numbers between 0 and 100:");
        System.out.print(prev + " ");
        
        while (current <= maxNumber) {
            System.out.print(current + " ");
            int next = prev + current;
            prev = current;
            current = next;
        }
    }
}

