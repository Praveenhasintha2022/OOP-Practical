
public class AsteriskPattern {
    public static void main(String[] args) {
        for (int i = 0; i < 6; i++) {
            System.out.print("* ");
        }
    }
}



public class AsteriskPattern {
    public static void main(String[] args) {
        int rows = 4;
        int columns = 6;
        
        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= columns; j++) {
                System.out.print("* ");
            }
            System.out.println(); // Move to the next line
        }
    }
}


public class NumberPattern {
    public static void main(String[] args) {
        int rows = 5;
        int columns = 5;
        int number = 1;
        
        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= columns; j++) {
                System.out.print(number + " ");
            }
            number += 2;
            System.out.println(); // Move to the next line
        }
    }
}




public class AsteriskTrianglePattern {
    public static void main(String[] args) {
        int rows = 6;
        
        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print("* ");
            }
            System.out.println(); // Move to the next line
        }
    }
}







public class NumberTrianglePattern {
    public static void main(String[] args) {
        int rows = 5;
        
        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(i + " ");
            }
            System.out.println(); // Move to the next line
        }
    }
}





public class NumberTrianglePattern {
    public static void main(String[] args) {
        int rows = 5;
        int number = 1;

        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(number + " ");
            }
            number += 2;
            System.out.println(); // Move to the next line
        }
    }
}




public class RightAlignedAsteriskTrianglePattern {
    public static void main(String[] args) {
        int rows = 6;

        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= rows - i; j++) {
                System.out.print("  "); // Print spaces for right alignment
            }
            for (int j = 1; j <= i; j++) {
                System.out.print("* ");
            }
            System.out.println(); // Move to the next line
        }
    }
}




public class RightAlignedPyramidPattern {
    public static void main(String[] args) {
        int rows = 6;

        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= rows - i; j++) {
                System.out.print("   "); // Print spaces for right alignment
            }
            for (int j = 1; j <= 2 * i - 1; j++) {
                System.out.print(" * ");
            }
            System.out.println(); // Move to the next line
        }
    }
}
