public class BoxPrinter {

    public static void printBox(String side) {
        
        if (side.length() == 0) {
            System.out.println("Error: Please provide a non-empty string for the side.");
            return;
        }

     
        for (int i = 0; i < side.length(); i++) {
            System.out.print(side.charAt(i) + " ");
        }
        System.out.println(); 

      
        for (int i = 1; i < side.length() - 1; i++) {
            System.out.print(side.charAt(i));
            for (int j = 0; j < side.length() - 2; j++) {
                System.out.print("  "); 
            }
            System.out.println(" " + side.charAt(i));
        }

       
        for (int i = 0; i < side.length(); i++) {
            System.out.print(side.charAt(i) + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
      
        printBox("12356");
    }
}
