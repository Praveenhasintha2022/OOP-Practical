public class StarPattern1 {
    public static void main(String[] args) {
        int n = 5;

        for (int i = 0; i  <  n; i++) {
            for (int j = 0; j  <  n; j++) {
                // Check if it's a border position
                if (i == 0 || i == n - 1 || j == 0 || j == n - 1)
                    System.out.print("*");
                else
                    System.out.print(" ");
            }
            System.out.println();
        }
    }
}




public class Main {
    public static void main(String[] args) {
        int n = 5;

        // Upper half of the diamond
        for (int i = 1; i  <= n; i++) {
            // Print left half of the row
            for (int j = 1; j  <= i; j++) {
                System.out.print("*");
            }
            // Print spaces in the middle
            for (int j = 1; j  <= 2 * (n - i); j++) {
                System.out.print(" ");
            }
            // Print right half of the row
            for (int j = 1; j  <= i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }

        // Lower half of the diamond
        for (int i = n; i  >= 1; i--) {
            // Print left half of the row
            for (int j = 1; j  <= i; j++) {
                System.out.print("*");
            }
            // Print spaces in the middle
            for (int j = 1; j  <= 2 * (n - i); j++) {
                System.out.print(" ");
            }
            // Print right half of the row
            for (int j = 1; j  <= i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}


public class Main {
    public static void main(String[] args) {
        int n = 5;

        // Upper half of the diamond
        for (int i = 0; i  <  n; i++) {
            // Print left side of the upper half
            for (int j = i; j  <  n; j++) {
                System.out.print("*");
            }
            // Print spaces in the middle
            for (int k = 0; k  <  2 * i; k++) {
                System.out.print(" ");
            }
            // Print right side of the upper half
            for (int j = i; j  <  n; j++) {
                System.out.print("*");
            }
            System.out.println();
        }

        // Lower half of the diamond
        for (int i = 1; i  <  n; i++) {
            // Print left side of the lower half
            for (int j = 0; j  <= i; j++) {
                System.out.print("*");
            }
            // Print spaces in the middle
            for (int k = 2 * (n - i - 1); k  >  0; k--) {
                System.out.print(" ");
            }
            // Print right side of the lower half
            for (int j = 0; j  <= i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}


public class Main {
    public static void main(String[] args) {
        int n = 7; // Must be odd

        for (int i = 0; i  <  n; i++) {
            for (int j = 0; j  <  n; j++) {
                // Check if the current position is in the center row or center column
                if (i == n / 2 || j == n / 2) {
                    System.out.print("*");
                } else {
                    System.out.print(" ");
                }
            }
            // Move to the next line after each row
            System.out.println();
        }
    }
}


public class Main {
    public static void main(String[] args) {
        int n = 5;

        for (int i = 0; i  <  n; i++) {
            // Print leading spaces
            for (int j = n - 1; j  >  i; j--) {
                System.out.print(" ");
            }

            // Print the first and last rows
            if (i == 0 || i == n - 1) {
                for (int k = 0; k  <= i; k++) {
                    System.out.print("* ");
                }
            } else {
                // Print the first asterisk
                System.out.print("*");

                // Print spaces inside the pyramid
                for (int k = 1; k  <  i; k++) {
                    System.out.print("  ");
                }

                // Print the second asterisk
                System.out.print(" *");
            }

            // Move to the next line
            System.out.println();
        }
    }
}



import java.util.Scanner;
public class Edureka
{
 
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of rows: ");
 
        int rows = sc.nextInt();        
        for (int i= 1; i<= rows ; i++)
        {
            for (int j=i; j <rows ;j++)            
        {
                System.out.print(" ");
            }
            for (int k=1; k<=i;k++) { System.out.print("*"); } System.out.println(""); } for (int i=rows; i>=1; i--)
        {
            for(int j=i; j<=rows;j++)
            {
                System.out.print(" ");
            }
            for(int k=1; k<i ;k++) 
            {
                System.out.print("*");
            }
            System.out.println("");
 
        }
        sc.close();
    }
}

 
 
 
 
 
 
 import java.util.Scanner;
public class Edureka
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of rows: ");
 
        int rows = sc.nextInt();            
        for (int i= 0; i<= rows-1 ; i++)
        {
            for (int j=0; j <i; j++)
            {
                System.out.print(" ");
            }
            for (int k=i; k<=rows-1; k++) { System.out.print("*" + " "); } System.out.println(""); } for (int i= rows-1; i>= 0; i--)
        {
            for (int j=0; j< i ;j++)
            {
                System.out.print(" ");
            }
            for (int k=i; k<=rows-1; k++)
            {
                System.out.print("*" + " ");
            }
            System.out.println("");
        }
        sc.close();
    }
}