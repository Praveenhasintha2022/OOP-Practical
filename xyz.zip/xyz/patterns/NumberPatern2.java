//down triangle
import java.util.Scanner;
public class NumberPatern2
{
public static void main(String[] args)
{
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the number of rows: ");
 
    int rows = sc.nextInt();    
     for (int i=rows; i>= 1 ; i--)
    {
        for (int j = i; j < rows ; j++) {
            System.out.print(" ");
        }   
        for (int k = 1; k <= (2*i -1) ;k++) {
            if( k==1 || i == rows || k==(2*i-1)) {
                System.out.print("*");
            }
            else {
                System.out.print(" ");
            }
        }
        System.out.println("");
    }
    sc.close();
}
}



Diamond import java.util.Scanner;
public class Edureka
{
    public static void main(String[] args)
{
    Scanner sc = new Scanner(System.in);
 
    System.out.println("Enter the number of rows: ");
 
    int rows = sc.nextInt();    
    for (int i=1; i<= rows ; i++) { for (int j = rows; j > i ; j--) {
            System.out.print(" ");
        }
        System.out.print("*");
        for (int k = 1; k < 2*(i -1) ;k++) { System.out.print(" "); } if( i==1) { System.out.println(""); } else { System.out.println("*"); } } for (int i=rows-1; i>= 1 ; i--)
        {
        for (int j = rows; j > i ; j--) {
            System.out.print(" ");
        }
        System.out.print("*");
        for (int k = 1; k < 2*(i -1) ;k++) {
            System.out.print(" ");
        }
        if( i==1)
            System.out.println("");
        else
            System.out.println("*");
    }
    sc.close();
}
}


Diamond Pattern Program in Java number
import java.util.Scanner;
  
public class Edureka
{            
    public static void main(String[] args) {
        for (int i = 1; i <= 4; i++)
        {
            int n = 4;
   
            for (int j = 1; j<= n - i; j++) { System.out.print(" "); } for (int k = i; k >= 1; k--)
            {
                System.out.print(k);
            }
            for (int l = 2; l <= i; l++) { System.out.print(l); } System.out.println(); } for (int i = 3; i >= 1; i--)
        {
            int n = 3;
   
            for (int j = 0; j<= n - i; j++) { System.out.print(" "); } for (int k = i; k >= 1; k--)
            {
                System.out.print(k);
            }
            for (int l = 2; l <= i; l++)
            {
                System.out.print(l);
            }
   
            System.out.println();
        }
       
    }
}

 
 
 Binary box
 import java.util.Scanner;
public class Edureka
{
      
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
          
        System.out.println("Enter the number of rows: ");
          
        int rows = sc.nextInt();
          
        for (int i = 1; i <= rows; i++) 
        {
            int num;
              
            if(i%2 == 0)
            {
                num = 0;
                  
                for (int j = 1; j <= rows; j++)
                {
                    System.out.print(num);
                      
                    num = (num == 0)? 1 : 0;
                }
            }
            else
            {
                num = 1;
                  
                for (int j = 1; j <= rows; j++)
                {
                    System.out.print(num);
                      
                    num = (num == 0)? 1 : 0;
                }
            }
              
            System.out.println();
        }
          
        sc.close();
    }
}            
    
	
Diamond Numeric Pattern
import java.util.Scanner;
public class Edureka
{
    public static void main(String[] args) 
    {
          
        int n = 5;  
          
        for (int i = 1; i <= n; i++) 
        {
            for (int j = 1; j < i; j++) 
            {
                System.out.print(" ");
            }
              
            for (int k = i; k <= n; k++) { System.out.print(k+" "); } System.out.println(); } for (int i = n-1; i >= 1; i--) 
        {
             for (int j = 1; j < i; j++) 
            {
                System.out.print(" ");
            }
            for (int k = i; k <= n; k++)
            {
                System.out.print(k+" ");
            }
              
            System.out.println();
        }
         
    }
}


K Shape Character Pattern Program
import java.util.Scanner;
 
public class Edureka
{public static void main(String[] args)
{
for (int i = 5; i >= 0; i--)
{
   int alphabet = 65;
   for (int j = 0; j <= i; j++)
   {
       System.out.print((char) (alphabet + j) + " ");
   }
   System.out.println();
}
for (int i = 0; i<= 5; i++)
{
   int alphabet = 65;
   for (int j = 0; j <= i; j++)
   {
       System.out.print((char) (alphabet + j) + " ");
   }
   System.out.println();
}
}
}
 
   Diamond Pattern in Java
   import java.util.Scanner;
 
public class Edureka
{public static void main(String[] args) {
    char[] letter = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
            'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
            'W', 'X', 'Y', 'Z' };
    int letter_number = 0;
    String[] diamond = new String[26]; // array of strings
    System.out.print("Enter a Character between A to Z : ");
 
    Scanner reader = new Scanner(System.in);
    try {
        char user_letter = reader.next("[A-Z]").charAt(0);
        // search for letter number in the array letter
        for (int i = 0; i < letter.length; i++) {
            if (letter[i] == user_letter) {
                letter_number = i;
                break;
            }
        }
 
        // construct diamond
        for (int i = 0; i <= letter_number; i++) {
            diamond[i] = "";
            // add initial spaces
            for (int j = 0; j < letter_number - i; j++) {
                diamond[i] += " ";
            }
 
            // add letter
            diamond[i] += letter[i];
 
            // add space between letters
            if (letter[i] != 'A') {
                for (int j = 0; j < 2 * i - 1; j++) { diamond[i] += " "; } // add letter diamond[i] += letter[i]; } // Draw the first part of the diamond System.out.println(diamond[i]); } for (int i = letter_number - 1; i >= 0; i--)
                {
            // Draw the second part of the diamond
            // Writing the diamondArray in reverse order
            System.out.println(diamond[i]);
        }
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        reader.close();
    }
 
}
}





class PrintChristmasTree{

	//Value 5 is permanently provided to height variable
public static final int height = 5;

//Main Function
public static void main(String[] args) {
	
	//Assigning Width 
	int width = 5;

	//Assigning Space
	int space = width*5;

	int x = 1;

	//Code to Print Upper Part of the Tree i.e. Pyramids.
	for(int a = 1;a <= height ;a++){

	for(int i = x;i <= width;i++){

		for(int j = space;j >= i;j--){

		System.out.print(" ");
		}

		for(int k = 1;k <= i;k++){

		System.out.print("* ");
		}

		System.out.println();
	}

	x = x+2;
	width = width+2;
	}


	//Printing Branch of Christmas Tree
	for(int i = 1;i <= 4;i++){

	for(int j = space-3;j >= 1;j--){
		
		System.out.print(" ");
	}

	for(int k= 1;k <= 4;k++){
		System.out.print("* ");
	}

	System.out.println();
	}
}
}



    import java.util.Scanner;  
    public class RightPascalTrianglePattern  
    {  
    public static void main(String[] args)  
    {  
    int i, j, rows;  
    Scanner sc = new Scanner(System.in);  
    System.out.print("Enter the number of rows you want to print: ");  
    rows = sc.nextInt();          
    for (i= 0; i<= rows-1; i++)  
    {  
    for (j=0; j<=i; j++)   
    {  
    System.out.print("*"+ " ");  
    }   
    System.out.println("");   
    }   
    for (i=rows-1; i>=0; i--)  
    {  
    for(j=0; j <= i-1;j++)  
    {  
    System.out.print("*"+ " ");  
    }  
    System.out.println("");  
    }  
    }  
    }  