import java.util.Scanner;

public class MaximumValue {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        int max = Integer.MIN_VALUE; // Initialize max to a very small value
        
        for (int i = 1; i <= 10; i++) {
            System.out.print("Enter positive integer " + i + ": ");
            int number = scanner.nextInt();
            
            if (number > max) {
                max = number;
            }
        }
        
        System.out.println("Maximum value among the entered integers: " + max);
        
        scanner.close();
    }
}
