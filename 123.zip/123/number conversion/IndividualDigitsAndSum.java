import java.util.Scanner;

public class IndividualDigitsAndSum {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter an integer: ");
        int number = scanner.nextInt();
        
        printIndividualDigitsAndSum(number);
        
        scanner.close();
    }
    
    public static void printIndividualDigitsAndSum(int num) {
        num = Math.abs(num); // Convert to positive if negative
        
        System.out.print("Individual digits: ");
        int sum = 0;
        
        while (num > 0) {
            int digit = num % 10;
            System.out.print(digit + " ");
            sum += digit;
            num /= 10;
        }
        
        System.out.println("\nSum of digits: " + sum);
    }
}
