import java.util.Scanner;

public class DecimalToBinary {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a positive integer: ");
        int decimalNumber = scanner.nextInt();
        
        String binaryNumber = convertToBinary(decimalNumber);
        System.out.println("Binary representation: " + binaryNumber);
        
        scanner.close();
    }
    
    public static String convertToBinary(int decimal) {
        if (decimal == 0) {
            return "0";
        }
        
        StringBuilder binary = new StringBuilder();
        
        while (decimal > 0) {
            int bit = decimal % 2;
            binary.insert(0, bit); // Insert the bit at the beginning
            decimal /= 2;
        }
        
        return binary.toString();
    }
}

