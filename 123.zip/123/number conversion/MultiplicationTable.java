public class MultiplicationTable {
    public static void main(String[] args) {
        int number = 5;
        
        System.out.println("Multiplication table of " + number + ":");
        
        for (int i = 1; i <= 12; i++) {
            int result = number * i;
            System.out.println(number + " * " + i + " = " + result);
        }
    }
}