import java.util.Scanner;

public class FactorialCalculator {

    // Function to calculate the factorial of a number
    public static long calculateFactorial(int n) {
        if (n == 0 || n == 1) {
            return 1; // Factorial of 0 and 1 is 1
        } else {
            // Recursive calculation for other values
            return n * calculateFactorial(n - 1);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input a non-negative integer from the user
        System.out.print("Enter a non-negative integer: ");
        int number = scanner.nextInt();

        // Validate that the input is non-negative
        if (number < 0) {
            System.out.println("Please enter a non-negative integer.");
        } else {
            // Call the function to calculate factorial and display the result
            long factorial = calculateFactorial(number);
            System.out.println("Factorial of " + number + " is: " + factorial);
        }

        // Close the scanner
        scanner.close();
    }
}

