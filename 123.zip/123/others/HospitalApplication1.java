import java.util.Scanner;

class Hospital {
    private String name;
    private String address;
    private Patient[] patients;
    private Department[] departments;
    private int patientCount;
    private int departmentCount;

    public Hospital(String name, String address) {
        this.name = name;
        this.address = address;
        this.patients = new Patient[100];
        this.departments = new Department[10];
        this.patientCount = 0;
        this.departmentCount = 0;
    }

    public void addPatient(Patient patient) {
        patients[patientCount++] = patient;
    }

    public void removePatient(Patient patient) {
        for (int i = 0; i < patientCount; i++) {
            if (patients[i] == patient) {
                patients[i] = null;
                break;
            }
        }
    }

    public void addDepartment(Department department) {
        departments[departmentCount++] = department;
    }

    public void removeDepartment(Department department) {
        for (int i = 0; i < departmentCount; i++) {
            if (departments[i] == department) {
                departments[i] = null;
                break;
            }
        }
    }
}

class Department {
    private String name;
    private TeamMember[] staff;
    private int teamMemberCount;

    public Department(String name) {
        this.name = name;
        this.staff = new TeamMember[20];
        this.teamMemberCount = 0;
    }

    public void addTeamMember(TeamMember teamMember) {
        staff[teamMemberCount++] = teamMember;
    }

    public void removeTeamMember(TeamMember teamMember) {
        for (int i = 0; i < teamMemberCount; i++) {
            if (staff[i] == teamMember) {
                staff[i] = null;
                break;
            }
        }
    }
}

class TeamMember {
    private String name;
    private String id;
    private String gender;
    private String joinDate;
    private int maxWorkingHours = 12;

    public TeamMember(String name, String id, String gender, String joinDate) {
        this.name = name;
        this.id = id;
        this.gender = gender;
        this.joinDate = joinDate;
    }

    public String getName() {
        return name;
    }

    public void treatPatient(Patient patient) {
        // Abstract method to be implemented by subclasses
    }
}

class Doctor extends TeamMember {
    private String specialty;
    private Patient[] patients;
    private int patientCount;

    public Doctor(String name, String id, String gender, String joinDate, String specialty) {
        super(name, id, gender, joinDate);
        this.specialty = specialty;
        this.patients = new Patient[20];
        this.patientCount = 0;
    }

    @Override
    public void treatPatient(Patient patient) {
        // Common treatment logic for all doctors
        patient.setDiagnosis("Treatment in progress");
        patient.setDoctor(this);
        patient.setDaysToStay(7);
    }
}

class Intern extends Doctor {
    private SeniorDoctor supervisor;

    public Intern(String name, String id, String gender, String joinDate, String specialty, SeniorDoctor supervisor) {
        super(name, id, gender, joinDate, specialty);
        this.supervisor = supervisor;
    }
}

class SeniorDoctor extends Doctor {
    public SeniorDoctor(String name, String id, String gender, String joinDate, String specialty) {
        super(name, id, gender, joinDate, specialty);
    }
}

class Surgeon extends Doctor {
    public Surgeon(String name, String id, String gender, String joinDate, String specialty) {
        super(name, id, gender, joinDate, specialty);
    }
}

class Patient {
    private String name;
    private String birthDate;
    private String gender;
    private String admissionDate;
    private String diagnosis;
    private TeamMember doctor;
    private int daysToStay;

    public Patient(String name, String birthDate, String gender, String admissionDate) {
        this.name = name;
        this.birthDate = birthDate;
        this.gender = gender;
        this.admissionDate = admissionDate;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    public void setDoctor(TeamMember doctor) {
        this.doctor = doctor;
    }

    public void setDaysToStay(int days) {
        this.daysToStay = days;
    }

    public String getName() {
        return name;
    }

    public TeamMember getDoctor() {
        return doctor;
    }

    public int getDaysToStay() {
        return daysToStay;
    }
}

public class HospitalApplication1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter hospital name: ");
        String hospitalName = scanner.nextLine();

        System.out.print("Enter hospital address: ");
        String hospitalAddress = scanner.nextLine();

        Hospital myHospital = new Hospital(hospitalName, hospitalAddress);

        System.out.print("Enter department name: ");
        String departmentName = scanner.nextLine();
        Department cardiology = new Department(departmentName);

        System.out.print("Enter doctor's name: ");
        String doctorName = scanner.nextLine();
        System.out.print("Enter doctor's ID: ");
        String doctorId = scanner.nextLine();
        System.out.print("Enter doctor's gender: ");
        String doctorGender = scanner.nextLine();
        System.out.print("Enter doctor's join date: ");
        String doctorJoinDate = scanner.nextLine();
        System.out.print("Enter doctor's specialty: ");
        String doctorSpecialty = scanner.nextLine();

        Doctor doctor1 = new SeniorDoctor(doctorName, doctorId, doctorGender, doctorJoinDate, doctorSpecialty);
        cardiology.addTeamMember(doctor1);

        System.out.print("Enter patient's name: ");
        String patientName = scanner.nextLine();
        System.out.print("Enter patient's birth date: ");
        String patientBirthDate = scanner.nextLine();
        System.out.print("Enter patient's gender: ");
        String patientGender = scanner.nextLine();
        System.out.print("Enter patient's admission date: ");
        String patientAdmissionDate = scanner.nextLine();

        Patient patient1 = new Patient(patientName, patientBirthDate, patientGender, patientAdmissionDate);

        myHospital.addDepartment(cardiology);
        myHospital.addPatient(patient1);

        doctor1.treatPatient(patient1);

        System.out.println("Patient: " + patient1.getName() +
                "\nTreated by Doctor: " + patient1.getDoctor().getName() +
                "\nDays to stay: " + patient1.getDaysToStay());
    }
}
