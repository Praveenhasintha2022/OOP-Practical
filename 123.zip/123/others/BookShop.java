import java.util.Scanner;

class Books {
    private String title;
    private String author;
    private double price;
    private String publisher;
    private int stock;

    public Books(String title, String author, double price, String publisher, int stock) {
        this.title = title;
        this.author = author;
        this.price = price;
        this.publisher = publisher;
        this.stock = stock;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public double getPrice() {
        return price;
    }

    public String getPublisher() {
        return publisher;
    }

    public int getStock() {
        return stock;
    }

    public void displayBookDetails() {
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("Price: Rs " + price);
        System.out.println("Publisher: " + publisher);
        System.out.println("Stock: " + stock);
    }

    public boolean isAvailable(int copiesRequired) {
        return stock >= copiesRequired;
    }

    public double calculateTotalCost(int copiesRequired) {
        return price * copiesRequired;
    }

    public void sellBooks(int copiesRequired) {
        if (isAvailable(copiesRequired)) {
            stock -= copiesRequired;
            System.out.println("Books sold successfully.");
        } else {
            System.out.println("Required copies not in stock.");
        }
    }
}

public class BookShop {
    public static void main(String[] args) {
		System.out.println("======================================================================================");
		System.out.println("                                 Book Shop");
	    System.out.println("======================================================================================");
		System.out.println("\nWe have the following Books");
		System.out.println("\nBook 1 From Author 1");
	    System.out.println("Book 2 From Author 2\n");
		
		
        Books book1 = new Books("Book 1", "Author 1", 2000, "Kamal", 18);
        Books book2 = new Books("Book 2", "Author 2", 1500, "Madushan", 13);

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the title of the book: ");
        String titleInput = scanner.nextLine();
        System.out.print("Enter the author of the book: ");
        String authorInput = scanner.nextLine();

        if (book1.getTitle().equals(titleInput) && book1.getAuthor().equals(authorInput)) {
            book1.displayBookDetails();
            System.out.print("Enter the number of copies required: ");
            int copiesRequired = scanner.nextInt();
            book1.sellBooks(copiesRequired);
            System.out.println("Total cost: Rs" + book1.calculateTotalCost(copiesRequired));
        } else if (book2.getTitle().equals(titleInput) && book2.getAuthor().equals(authorInput)) {
            book2.displayBookDetails();
            System.out.print("Enter the number of copies required: ");
            int copiesRequired = scanner.nextInt();
            book2.sellBooks(copiesRequired);
            System.out.println("Total cost: Rs " + book2.calculateTotalCost(copiesRequired));
        } else {
            System.out.println("Book not found in the inventory.");
        }
    }
}
