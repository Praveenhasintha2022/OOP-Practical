public class SavingsAccount {
    public static double annualInterestRate;
    private double savingsBalance;

    public SavingsAccount() {
        // Default constructor
    }

    public SavingsAccount(double intRate, double savBal) {
        annualInterestRate = intRate;
        savingsBalance = savBal;
    }

    public double calculateMonthlyInterest() {
        double monthlyInterest = (savingsBalance * annualInterestRate) / 12;
        savingsBalance += monthlyInterest;
        return monthlyInterest;
    }

    public static void modifyInterestRate(double newInterestRate) {
        annualInterestRate = newInterestRate;
    }

    public void setSavingsBalance(double newBal) {
        savingsBalance = newBal;
    }

    public double getSavingsBalance() {
        return savingsBalance;
    }

    public double getAnnualInterestRate() {
        return annualInterestRate;
    }

    public static void main(String[] args) {
        // Instantiate two savingsAccount objects
        SavingsAccount saver1 = new SavingsAccount(0.04, 2000.00);
        SavingsAccount saver2 = new SavingsAccount(0.04, 3000.00);

        // Set annualInterestRate to 4%
        SavingsAccount.modifyInterestRate(0.04);
        
        // Calculate and print the monthly interest and new balances
        System.out.println("Month 1:");
        System.out.println("Saver 1 balance before: Rs. " + saver1.getSavingsBalance());
        System.out.println("Saver 2 balance before: Rs. " + saver2.getSavingsBalance());
        System.out.println("Saver 1 monthly interest: Rs. " + saver1.calculateMonthlyInterest());
        System.out.println("Saver 2 monthly interest: Rs. " + saver2.calculateMonthlyInterest());
        System.out.println("Saver 1 balance after: Rs. " + saver1.getSavingsBalance());
        System.out.println("Saver 2 balance after: Rs. " + saver2.getSavingsBalance());

        // Set annualInterestRate to 5%
        SavingsAccount.modifyInterestRate(0.05);

        // Calculate and print the next month interest and new balances
        System.out.println("\nMonth 2:");
        System.out.println("Saver 1 balance before: Rs. " + saver1.getSavingsBalance());
        System.out.println("Saver 2 balance before: Rs. " + saver2.getSavingsBalance());
        System.out.println("Saver 1 monthly interest: Rs. " + saver1.calculateMonthlyInterest());
        System.out.println("Saver 2 monthly interest: Rs. " + saver2.calculateMonthlyInterest());
        System.out.println("Saver 1 balance after: Rs. " + saver1.getSavingsBalance());
        System.out.println("Saver 2 balance after: Rs. " + saver2.getSavingsBalance());
    }
}
