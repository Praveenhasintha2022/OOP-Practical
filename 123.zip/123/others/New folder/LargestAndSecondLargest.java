import java.util.Scanner;

public class LargestAndSecondLargest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Get the number of elements in the array
        System.out.print("Enter the number of elements: ");
        int n = scanner.nextInt();
        
        // Validate input
        if (n < 2) {
            System.out.println("Please enter at least two values.");
            return;
        }
        
        int[] arr = new int[n];
        
        // Get the elements of the array
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }
        
        // Find the largest and second-largest numbers
        int largest = Integer.MIN_VALUE;
        int secondLargest = Integer.MIN_VALUE;
        
        for (int num : arr) {
            if (num > largest) {
                secondLargest = largest;
                largest = num;
            } else if (num > secondLargest && num != largest) {
                secondLargest = num;
            }
        }
        
        // Display the results
        System.out.println("Largest number: " + largest);
        System.out.println("Second largest number: " + secondLargest);
        
        scanner.close();
    }
}
