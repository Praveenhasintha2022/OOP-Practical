class DaysReservedException extends Exception {
    public DaysReservedException(String message) {
        super(message);
    }
}

class Hotel {
    private String name;
    private int starsRank;
    public static int availableRooms;

    public Hotel(String name, int starsRank, int availableRooms) {
        this.name = name;
        this.starsRank = starsRank;
        Hotel.availableRooms = availableRooms;
    }

    public String getName() {
        return name;
    }

    public int getStarsRank() {
        return starsRank;
    }

    public static int getAvailableRooms() {
        return availableRooms;
    }

    public static void incrementAvailableRooms() {
        availableRooms++;
    }

    public static void decrementAvailableRooms() {
        availableRooms--;
    }
}

class Room {
    private int roomId;
    private double price;
    private String type;

    public Room(int roomId, double price, String type) {
        this.roomId = roomId;
        this.price = price;
        this.type = type;
    }

    public int getRoomId() {
        return roomId;
    }

    public double getPrice() {
        return price;
    }

    public String getType() {
        return type;
    }

    public void displayRoomInfo() {
        System.out.println("Room ID: " + roomId);
        System.out.println("Price: LKR " + price);
        System.out.println("Type: " + type);
    }
}

class Resident {
    private int id;
    private String name;
    private int daysToStay;
    private Room room;
    private double finalCost;

    public Resident(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public void reserveRoom(Room room, int days) throws DaysReservedException {
        if (days < 1) {
            throw new DaysReservedException("Number of days reserved should be at least 1.");
        }

        this.room = room;
        this.daysToStay = days;

        this.finalCost = room.getPrice() * days;
        Hotel.decrementAvailableRooms();
    }

    public void displayResidentInfo() {
        System.out.println("Resident ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Days to stay: " + daysToStay);
        room.displayRoomInfo();
        System.out.println("Final Cost: LKR " + finalCost);
    }
}

public class HotelManagementSystem {
    public static void main(String[] args) {
        Hotel hotel = new Hotel("Grand Hotel", 5, 3);

        Room singleRoom = new Room(101, 2000.00, "Single");
        Room doubleRoom = new Room(102, 3500.00, "Double");
        Room tripleRoom = new Room(103, 5000.00, "Triple");

        Resident resident1 = new Resident(1, "John");
        Resident resident2 = new Resident(2, "Alice");

        try {
            resident1.reserveRoom(singleRoom, 3);
            System.out.println("Number of available rooms after reservation: " + Hotel.getAvailableRooms());

            resident2.reserveRoom(doubleRoom, 2);
            System.out.println("Number of available rooms after reservation: " + Hotel.getAvailableRooms());
        } catch (DaysReservedException e) {
            System.out.println("Error: " + e.getMessage());
        }

        System.out.println("Resident 1 Info:");
        resident1.displayResidentInfo();

        System.out.println("Resident 2 Info:");
        resident2.displayResidentInfo();
    }
}
